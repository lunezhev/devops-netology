# Ansible Collection - my_own_namespace.yandex_cloud_elk

Collection include: Role: my_own_role Module: my_own_module

Module creates a text file with the given content at the given path.

Two options are required:

path - the path to create the file including the file name. content - the content of the file.